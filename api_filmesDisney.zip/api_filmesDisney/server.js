const express = require('express');
const bodyParser = require('body-parser');
const { Sequelize } = require('sequelize');
const config = require('./config')

const app = express();
const port = 80;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

const bancoo = new Sequelize(config.development);

const Filme = require('./Models/filmes')(bancoo, Sequelize);

bancoo.sync().then(() => {
    console.log("Modelo sincronizado com o banco de dados.")
});


app.get('/filmes', async (req, res) => {
    const filmes = await Filme.findAll();
    res.json(filmes);
});

app.get('/filmes/:id', async (req, res) => {
    const {id} = req.params;
    const filmes = await Filme.findByPk(id)
    res.json(filmes);
});

app.post('/filmes', async (req, res) => {
    const {name, genero, dataLacamento, avaliacao} = req.body;
    const filme = await Filme.create({name, genero, dataLacamento, avaliacao});
    res.json(filme);
});

app.put('/filmes/:id', async (req, res) => {
    const {id} = req.params;
    const {name, genero, dataLacamento, avaliacao} = req.body;
    
    await Filme.update({name, genero, dataLacamento, avaliacao}, {where: {id} });
    const filme = await Filme.findByPk(id);

    res.json(filme);
});

app.delete('/filmes/:id', async (req, res) => {
    const {id} = req.params;

    await Filme.destroy({where: {id} });
    res.json({message: 'Filme deletado com sucesso!'})
});

app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});