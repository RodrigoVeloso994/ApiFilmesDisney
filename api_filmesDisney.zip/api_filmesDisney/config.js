module.exports = {
    development: {
        database: 'db-bz2y2x4rjc66',
        username: 'db-bz2y2x4rjc66',
        password: 'ZCP7S192qU2C9RFGdjJZTX8L',
        host: 'up-es-mad1-mysql-1.db.run-on-erla.com',
        port: '11550',
        dialect: 'mysql'
    },
};