module.exports = (sequelize, DataTypes) => {
    const Filmes = sequelize.define('filmes', {
        nome: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        genero: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        dataLancamento: {
            type: DataTypes.DATE,
            allowNull: false,
        },
        avaliacao: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    },
    {
        freezeTableName: true,
        tableName: 'filmes',
        timestamps: true,
        createdAt: 'dataCriacao',
        updatedAt: 'dataAtualizacao',
        version: 'versao'
    }
    );
    return Filmes;
};